function [] = NEWUOAStep10()
%NEWUOAStep10 ��ӦNEWUOA�㷨�ĵ�ʮ��

global delta RATIO NORMD rho
global Steps %������
Steps=[Steps;10];
M1=max(NORMD,delta);
if ( (M1-rho)/rho<10^-6 )&&( RATIO<=0  )
    NEWUOAStep11();%To NEWUOAStep11
else
    NEWUOAStep2();%To NEWUOAStep2
end

end