function [] = NEWUOAStep2()
%NEWUOAStep2 ��ӦNEWUOA�㷨�ĵڶ���
%   ��ֵ����ʽΪQ(x)=c+g'*(x-x0)+0.5*(x-x0)'*G*(x-x0)
%   G=Gamma+sum(lambda(j)(Xn(:,j)-x0)*(Xn(:,j)-x0)');
%   Ŀ�꺯��ΪQ(xopt+d)
%   Լ������Ϊ ||d||<=delta
%   ����Ϊ�ضϹ����ݶȷ�
%   XX=Xn-x0;
global n g x0 Xn Fn opt delta CRVMIN d NORMD Qnew
global Steps %������
Steps=[Steps;2];
xopt=Xn(:,opt);
Fopt=Fn(opt);
d=zeros(n,1);
NORMD=0;
ITERC=0;
ITERMAX=n;
ITERSW=ITERMAX;
DELSQ=delta*delta;
%% �ضϹ����ݶȷ�
QRED=0;
SS=0;
s=xopt-x0;
HS=qHD(s);
d=zeros(n,1);
DD=0;
HD=zeros(n,1);
G=g+HS;%Q'(xopt)=g+H*(xopt-x0);
s=-G;
SS=s'*s;
CRVMIN=0;%Ĭ������Ϊ0
DS=0;
DD=0;
GG=SS;
GGBEG=GG;
K1=0;%(5.13)(2)
K2=0;%(5.13)(1)
K3=0;
K4=0;
K5=0;
if (SS < 10e-15)
    Qnew=Fopt;
else
    while(ITERC<=ITERMAX)
        ITERC=ITERC+1;
        TEMP=DELSQ-DD;
        BSTEP=TEMP/(DS+sqrt(DS*DS+SS*TEMP));
        HS=qHD(s);
        SHS=s'*HS;
        ALPHA=BSTEP;
        if(SHS> 0)
            TEMP=SHS/SS;%��ʽ(5.14)
            if (ITERC == 1)
                CRVMIN=TEMP;
            end
            CRVMIN=max([CRVMIN,TEMP]);
            ALPHA=max([ALPHA,GG/SHS]);%��ʽ(5.10)
        end
        QADD=ALPHA*(GG-0.5*ALPHA*SHS);% ��ʽ(5.8)
        QRED=QRED+QADD;
        GGSAV=GG;
        GG=0;
        d=d+ALPHA*s;
        HD=HD+ALPHA*HS;
        GG=(G+HD)'*(G+HD);
        if (ALPHA < BSTEP)
            if (QADD <0.01D0*QRED)%��ʽ(5.13)�����Ǹ�
                K1=1;
                break;
            end
            if (GG <= 1.0D-4*GGBEG)%��ʽ(5.13)�����Ǹ�
                K2=1;
                break;
            end
            TEMP=GG/GGSAV; %��ʽ(5.5)�е�BETA_j
            DD=ZERO;
            DS=ZERO;
            SS=ZERO;
            s=TEMP*s-G-HD;
            SS=s'*s;
            DS=d'*s;
            DD=d'*d;
            if (DS <= 0)
                K3=1;
                break;
            end
            if(DD>=DELSQ)
                K4=1;
                break;
            end
        else
            K5=1;
            break;
        end
    end
    if K5==1 ||(K1==0&&K2==0&&K3==0&&K4==1&&(ITERC<ITERMAX))
        CRVMIN=0;% DD=DELSQ,��ǰ�漸������ʽ��������
        ITERSW=ITERC;
    end
    xnew=xopt+d-x0;
    Qnew=Fopt+g'*xnew*0.5*xnew'*qHD(xnew);
    %% ���ⲿ��
    if(  (K1+K2+K3<1)&&(ITERC<ITERMAX) )
        while(GG>1.0e-4*GGBEG)%������ⲿ�ֵ�����1
            DG=d'*G;
            DHD=d'*HD;
            DGK=DG+DHD;
            ANGTEST=DGK/sqrt(GG*DELSQ);
            if (ANGTEST > -0.99D0) %������ⲿ�ֵ�����2
                %49��������
                CTH=zeros(49,1);
                STH=zeros(49,1);
                ANGLE=zeros(49,1);
                dPi=2*pi/50;
                for i=1:49
                    ANGLE(i)=dPi*i;
                    CTH(i)=cos(ANGLE(i));
                    STH(i)=sin(ANGLE(i));
                end
                %
                ITERC=ITERC+1;
                TEMP=sqrt(DELSQ*GG-DGK*DGK);
                TEMPA=DELSQ/TEMP;
                TEMPB=DGK/TEMP;
                s=TEMPA*(G+HD)-TEMPB*d;
                SG=0;
                SHS=0;
                SHD=0;
                SG=SG+s'*G;
                SHS=SHS+s'*HS;
                SHD=SHD+HS'*d;
                QBEG=Fopt+DG+0.5*DHD;%Q(xopt+d);Q'(xopt+d)-Q'(xopt)=g+H(xopt+d-x0)-g-H(xopt-x0)=HD;
                QMIN=QBEG;
                QSAV=QBEG;
                ISAVE=0;
                for i=1:49
                    QNEW=Fopt+CTH(i)*DG+STH(i)*SG+0.5*(CTH(i)^2*DHD+CTH(i)*STH(i)*SHD+STH(i)^2*SHS);
                    if (QNEW < QMIN)
                        QMIN=QNEW;
                        ISAVE=i;
                        TEMPA=QSAV;
                    else if (i == ISAVE+1)
                            TEMPB=QNEW;
                        end
                    end
                    QSAV=QNEW;
                end
                if (ISAVE == 0)
                    TEMPA=QNEW;
                end
                if (ISAVE == 49)
                    TEMPB=QBEG;
                end
                angle=0;
                if (TEMPA ~= TEMPB)
                    TEMPA=TEMPA-QMIN;
                    TEMPB=TEMPB-QMIN;
                    angle=0.5*(TEMPA-TEMPB)/(TEMPA+TEMPB);
                end
                angle=dPi*(ISAVE+angle);
                cosA=cos(angle);
                sinA=sin(angle);
                Qnew=Fopt+cosA*DG+sinA*SG+0.5*(cosA^2*DHD+cosA*sinA*SHD+sinA^2*SHS);
                d=cosA*d+sinA*s;
                HD= cosA*HD+sinA*HS;
                GG=(G+HD)'*(G+HD);
                RATIO=(QBEG-Qnew)/(Fopt-Qnew);
                if( (RATIO<=0.01) || (ITERC >= ITERMAX) )
                    break;
                end
            else
                break;
            end
        end
    end  
end
%%
NORMD=sqrt(d'*d);
%%
NEWUOAStep3();
end
function [hs]=qHD(s)
%�������G������s�Ŀ����㷨������s��n*1��
global Gamma gamma XX0 m
eta=gamma.*(XX0'*s);
hs=Gamma*s;
for i=1:m
    hs=hs+eta(i)*XX0(:,i);%%��ʽ(5.3)
end
end
