function [] = NEWUOAStep7()
%NEWUOAStep7 ��ӦNEWUOA�㷨�ĵ��߲�

global DIST MOVE opt Xn n m XXopt NXX
global Steps %������
Steps=[Steps;7];
DIST=0;
XXopt=zeros(n,m);
NXX=zeros(1,m);
for i=1:m
    XXopt(:,i)=Xn(:,i)-Xn(:,opt);
    NXX(i)=sqrt(XXopt(:,i)'*XXopt(:,i));
    if NXX(i)>DIST
        DIST=NXX(i);
        MOVE=i;
    end
end
NEWUOAStep8();%To Setp8

end