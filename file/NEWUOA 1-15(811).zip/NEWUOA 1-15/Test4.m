clear all
warning off 
%%
%��ʼ������
n=2;
m=2*n+1;
rho_beg=1;
rho_end=10^(-6);
Max=100;
xb=[100;100];
% xb=[100];
%%
%���Ժ���
load('titles.mat')
for i=86:96
F_test=@(x)(TestProblemF(x,n,titles(i)));
%%
global Xn Fn n m F_times rho_beg rho_end x0 opt xb c g Gamma gamma H F rho delta Krho D3 QF3 CRVMIN d NORMD Qnew 
global RATIO MOVE w Hw beta Fnew DIST XXopt NXX 
global Test DandR
[Fopt,xopt] = NEWUOAMethod(F_test,m,n,xb,rho_beg,rho_end,Max);
i
end