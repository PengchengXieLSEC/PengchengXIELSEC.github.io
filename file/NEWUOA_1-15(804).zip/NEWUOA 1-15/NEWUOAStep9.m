function [] = NEWUOAStep9()
%NEWUOAStep9 ��ӦNEWUOA�㷨�ĵھŲ�
%BIGLAGandBIGDENOfNEWUOA �ƶ���ֵ��ķ���
%   Ŀ�꺯��Ϊ|l_t(xopt+d)|
%   Լ������Ϊ ||d||<=deltah
%%
global F d NORMD beta w Hw rho delta DIST H Xn MOVE opt x0 n m RATIO Fnew Qnew F_times Krho XXopt NXX XX0
%BIGLAG
deltah=max([min([0.1*DIST,0.5*delta]),rho]);
DELSQ=deltah*deltah;
N=n;
t=MOVE;
xt=Xn(:,t);
xopt=Xn(:,opt);
% X=Xn-x0;=XX0
%%
%l_t(x)=c+g*(x-x0)+0.5*(x-x0)'*G*(x-x0)
Lambda=diag(H(1:m,t));
c=H(m+1,t);
g=H(m+2:m+n+1,t);
G=XX0*Lambda*XX0';
%%
Dl=g+G*XX0(:,opt);%Dlt(xopt)=g+G*(xopt-x0);
eta=@(u)(H(1:m,t).*(XX0'*u));
DDlu=@(u)( XX0*eta(u) );
xx=XXopt(:,t);%xx=xt-xopt;
d=deltah*(xx/norm(xx));
%d2=-d1;
GD=DDlu(d);
DD=d'*d;
GG=Dl'*Dl;
SP=d'*Dl;
DHD=d'*GD;
if  (SP*DHD <= 0)
    d=-d;
    GD=-GD;
    lxd=abs(-SP+0.5*DHD);
else
    lxd=abs(SP+0.5*DHD);
end 
TEMP=0;
if(SP*SP >= 0.99*DD*GG)||(GG*DELSQ <= 0.01*lxd*lxd) %%�Ƿ�ƽ��
    TEMP=1;
end
S=Dl+TEMP*GD;
K1=0;%�������
CTH=zeros(49,1);
STH=zeros(49,1);
ANGLE=zeros(49,1);
dPi=2*pi/50;
for i=1:49
    ANGLE(i)=dPi*i;
 CTH(i)=cos(ANGLE(i));
 STH(i)=sin(ANGLE(i));
end
while K1<=N
    K1=K1+1;
    DD=d'*d;
    SP=d'*S;
    SS=S'*S;
    TEMP=DD*SS-SP*SP;
    if (TEMP <= 1.0D-8*DD*SS)
        break;
    end
    DENOM=sqrt(TEMP);
    S=(DD*S-SP*d)/DENOM;%����S
    W=DDlu(S);
    CF1=0.5*S'*W;
    CF2=d'*Dl;
    CF3=S'*Dl;
    CF4=0.5*d'*GD-CF1;
    CF5=S'*GD;
    TAUBEG=CF1+CF2+CF4;
    TAUMAX=TAUBEG;
    TAUOLD=TAUBEG;
    ISAVE=0;
    for i=1:49
       TAU=CF1+(CF2+CF4*CTH(i))*CTH(i)+(CF3+CF5*CTH(i))*STH(i);
                if (abs(TAU) >= abs(TAUMAX)) 
                    TAUMAX=TAU;
                    ISAVE=i;
                    TEMPA=TAUOLD;
                else
                    if ( i ==(ISAVE+1) )
                    TEMPB=TAU;
                    end
                end 
       TAUOLD=TAU;
    end
    if (ISAVE == 0)
        TEMPA=TAU;
    end
    if (ISAVE == 49)
        TEMPB=TAUBEG;
    end
    STEP=0;
    if (TEMPA ~= TEMPB) 
    TEMPA=TEMPA-TAUMAX;
    TEMPB=TEMPB-TAUMAX;
    STEP=0.5*(TEMPA-TEMPB)/(TEMPA+TEMPB);
    end
    angle=dPi*(ISAVE+STEP);
    TAU=CF1+(CF2+CF4*cos(angle))*cos(angle)+(CF3+CF5*cos(angle))*sin(angle);
    d=cos(angle)*d+sin(angle)*S;
    GD=cos(angle)*GD+sin(angle)*W;
    S=Dl+GD;
     if (abs(TAU) <= 1.1D0*abs(TAUBEG))
         break;
     end
end
%%
NORMD=deltah;
xnew=xopt+d;
alpha=H(t,t);
w=zeros(m+n+1,1);
xx0=xnew-x0;
for i=1:m
    w(i)=0.5*((XX0(:,i)'*xx0)^2);
end
w(m+1)=1;
w(m+2:m+n+1)=xx0;
Hw=H*w;
beta=0.5*(norm(xx0)^4)-w'*Hw;
tau=Hw(t);
tau2=tau*tau;
%%
%BIGDEN
if abs(alpha*beta+tau2)<=0.8*tau2
    S=XXopt(:,t);
    DD=d'*d;
    DS=d'*S;
    SS=S'*S;
    v=zeros(m+n+1,1);
    for i=1:m
        v(i)=0.5*((XX0(:,i)'*XX0(:,opt))^2);
    end
    v(m+1)=1;
    v(m+2:m+n+1)=XX0(:,opt);
    NCN=0.5*((XX0(:,opt)'*XX0(:,opt))^2);
    DEN=@(d)(DENFunction(d,v,t,NCN));
    Weight=DS*DS/(DD*SS);
    Kt=t;
    if (Weight>= 0.99) 
        for i=1:m
            if i~=opt
                DSTEMP=XXopt(:,i)'*d;
                SSTEMP=NXX(i)^2;
               Weightnew=DSTEMP*DSTEMP/(DD*SSTEMP); 
               if Weightnew<=Weight
                   Kt=i;
                   Weight=Weightnew;
                   DS=DSTEMP;
                   SS=SSTEMP;
               end
            end
        end
        S=XXopt(:,Kt);
    end
    SSDEN=DD*SS-DS*DS;
    K2=0;
    TEMP=1/sqrt(SSDEN);
    S=TEMP*(DD*S-DS*d);
    while(K2<=N)
    DENTEST=zeros(1,50);
    DENTEST(1)=abs(DEN(d));
    for i=1:49
        dtest=CTH(i)*d+STH(i)*S;
        DENTEST(i+1)=abs(DEN(dtest));
    end
    [DENMAX,ISAVE]=max(DENTEST);
    if ISAVE==1
        TEMPA=DENTEST(50);
        TEMPB=DENTEST(2);
    else
        if ISAVE==50
        TEMPA=DENTEST(49);
        TEMPB=DENTEST(1);
        else
        TEMPA=DENTEST(ISAVE-1);
        TEMPB=DENTEST(ISAVE+1); 
        end
    end
                   if (TEMPA ~= TEMPB) 
                    TEMPA=TEMPA-DENMAX;
                    TEMPB=TEMPB-DENMAX;
                    STEP=0.5*(TEMPA-TEMPB)/(TEMPA+TEMPB);
                   end
     angle=dPi*(ISAVE+STEP);
     d=cos(angle)*d+sin(angle)*S;
     [DENNEW,w,Hw,beta,S]=DENFALL(d,v,t,NCN);
     if K2==0
         DENOLD=abs(DENNEW);
     else
         if (abs(DENNEW) <= 1.1*DENOLD)
             DENOLD=abs(DENNEW);
             break;
         else
             DENOLD=abs(DENNEW);
         end
     end
    DD=d'*d;
    DS=d'*S;
    SS=S'*S;
    SSDEN=DD*SS-DS*DS;
    if (SSDEN >= 1.0D-8*DD*SS)
        K2=K2+1;
    TEMP=1/sqrt(SSDEN);
    S=TEMP*(DD*S-DS*d);
    else
        break;
    end
    end
end

%%
xopt=Xn(:,opt);
xnew=xopt+d;%�����ɵĵ�
Fnew=F(xnew);
Qnew=Q(xnew);
F_times=F_times+1;
Krho=Krho+1;
RATIO=1;
NEWUOAStep5();%To Setp5
end
function DEN=DENFunction(d,v,t,C)
% C=0.5*||xopt-x0||^4
global Xn m n XX0 opt x0 H 
    Xnew=Xn(:,opt)+d;
    xx0=Xnew-x0;
    w=zeros(m+n+1,1);
    for i=1:m
        w(i)=0.5*((XX0(:,i)'*xx0)^2);
    end
    w(m+1)=1;
    w(m+2:m+n+1)=xx0;
    alpha=H(t,t);
    wv=w-v;
    Hwv=H*wv;
    DEN=alpha*(0.5*((xx0'*xx0)^2)-(XX0(:,opt)'*xx0)^2 + C  )-alpha*(wv'*Hwv)+Hwv(t);
    
end
function [DEN,w,Hw,beta,DDEN]=DENFALL(d,v,t,C)
% ����[DEN,w,DDEN]
% C=0.5*||xopt-x0||^4
global Xn m n XX0 opt x0 H 
    Xnew=Xn(:,opt)+d;
    xx0=Xnew-x0;
    w=zeros(m+n+1,1);
    for i=1:m
        w(i)=0.5*((XX0(:,i)'*xx0)^2);
    end
    w(m+1)=1;
    w(m+2:m+n+1)=xx0;
    alpha=H(t,t);
    wv=w-v;
    Hwv=H*wv;
    NX0=(xx0'*xx0);
    DEN=alpha*(0.5*(NX0^2)-(XX0(:,opt)'*xx0)^2 + C  )-alpha*(wv'*Hwv)+Hwv(t);
    
    %%
    %����DDEN
    Hw=H*w;
    beta=0.5*(NX0^2)-w'*Hw;
    tau=Hw(t);
    eta1=Hwv(1:m);
    eta2=Hwv(m+2:m+n+1);
    DDEN2=zeros(n,1);
    DDEN3=zeros(n,1);
        for i=1:m
            DDEN2=DDEN2+((tau*H(t,i)-alpha*eta1(i))*(xx0'*XX0(:,i)))*XX0(:,i);
        end
        DDEN2=2*DDEN2;
        for i=1:n
            DDEN3(i)=2*(tau*H(t,i+m+1)-alpha*eta2(i));
        end
        DDEN=2*alpha*(NX0*d+d'*xx0*XX0(:,opt))+(DDEN2)+(DDEN3);
end