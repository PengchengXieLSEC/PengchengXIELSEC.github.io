clear all
clc
warning off
%��ʼ������
n=20;
m=2*n+1;
rho_beg=1;
rho_end=10^(-6);
Max=20000;
%%
xb=10*ones(n,1);
problem=[11 17 42 43 45 55 66 70 71 75 76];
%%
%���Ժ���
prob = textread('problems', '%s');
load('titles.mat')
Fopt1=zeros(94,1);
NF=zeros(94,1);
Xopt1=zeros(n,94);
Fopt2=zeros(94,1);
Xopt2=zeros(n,94);
Index=[];
for i=92:92
    
    i
    try
        %F_test=@(x)(FFF(prob{i},x));
        F_test=@(x)(TestProblemF(x,n,prob{i}));
        %%
        global Xn Fn n m F_times rho_beg rho_end x0 opt xb c g Gamma gamma H F rho delta Krho D3 QF3 CRVMIN d NORMD Qnew
        global RATIO MOVE w Hw beta Fnew DIST XXopt NXX
        global Test DandR Steps
        [xb, rho_beg] = setuptest(prob{i}, n)
        [Fopt1(i),Xopt1(:,i),NF(i)] = NEWUOAMethodV1(F_test,m,n,xb,rho_beg,rho_end,Max);
        Fopt1(i),NF(i)
        %Test=[]; DandR=[]; Steps=[];
        %[Xopt2(:,i),Fopt2(i)] = fminsearch(F_test,xb);
    catch
        Index=[Index i];
    end
end


% E=rand(3,100)*1000;
% for i=1:100
% P(i,1)=evalfun('chpowellb',E(:,i));
% P(i,2)=TestProblemF(E(:,i),3,'chpowellb');
% end
% C=P(:,1)-P(:,2);