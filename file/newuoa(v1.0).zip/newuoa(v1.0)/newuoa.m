function [x, fx, exitflag, output] = newuoa(fun, x0, options)

if (nargin == 1)
    x0 = 0;
end
n = length(x0);

% Default options:
rhobeg = 1;
rhoend = 1e-6;
maxfun = 100*n;
npt = 2*n+1;
ftarget = -Inf;
debug = true;
chkfunval = false;
warndim = false;
subspace = false;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (nargin == 3)
    if (~isa(options, 'struct'))
        error('NEWUOA:InvalidOptions', 'options should be a structure.');
    end
    if (isfield(options,'rhobeg'))
        rhobeg = options.rhobeg;
    end
    if (isfield(options,'rhoend')) 
        rhoend = max(options.rhoend, eps);
    end
    if (isfield(options,'maxfun')) 
        maxfun = int32(options.maxfun);
    end
    if (isfield(options,'npt')) 
        npt = int32(options.npt);
    end
    if (isfield(options,'ftarget')) 
        ftarget = options.ftarget;
    end
    if (isfield(options,'debug')) 
        debug = options.debug;
    end
    if (isfield(options,'chkfunval')) 
        debug = options.chkfunval;
    end
    if (isfield(options,'warndim')) 
        warndim = options.warndim;
    end
    if (isfield(options,'subspace')) 
        subspace = options.subspace;
    end
end

if (~isa(fun, 'function_handle') && ~isa(fun, 'char'))
    error('NEWUOA:InvalidFun', 'fun should be a function handle or function name.');
end

if (~isnumeric(x0) || ~isvector(x0))
    error('NEWUOA:InvalidX0', 'x0 should be a numerical vector or scalar.')
end
x0 = x0(:);

if (~isnumeric(rhobeg) || ~isnumeric(rhoend) || rhobeg <=0 || rhoend < 0 || rhobeg < rhoend)
    error('NEWUOA:InvalidRhobegRhoend', 'rhobeg and rhoend should be real numbers satisfying\nrhobeg >= rhoend >= 0 and rhobeg > 0.');
end

if (maxfun < 1)
    error('NEWUOA:InvalidMaxfun', 'maxfun should be a positive integer.');
end

if (npt < n+2 || npt > (n+1)*(n+2)/2)
    error('NEWUOA:InvalidNpt', 'npt should be a positive integer stisfying\nn+2 <= npt <=(n+1)*(n+2)/2.');
end

if (debug == true && chkfunval == true)
    warning('NEWUOA:Chkfunval', 'NEWUOA is in debug mode and checks whether fx=fun(x) at exit, \nwhich will cost an extra function evaluation. Set options.debug=false \nor options.chkfunval=false to disable the check.');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if (subspace == true) % Use NEWUOAs instead of NEWUOA.
    options.subspace = true;
    [x, fx, newuoas_exitflag, newuoas_output] = newuoas(fun, x0, options);
    exitflag = 5; 
    output.algorithm = 'NEWUOAs';
    output.message = 'The optimization problem is solved by NEWUOAs.';
    output.newuoas_exitflag = newuoas_exitflag;
    output.newuoas_message = newuoas_output.message;
    output.newuoas_iterations = newuoas_output.iterations;
    if (isfield(newuoas_output, 'approx_1stopt'))
        output.newuoas_approx_1stopt = newuoas_output.approx_1stopt; 
    end
    output.funcCount = newuoas_output.funcCount;
    output.fhist = newuoas_output.fhist;
    return;
elseif (n >= 30 && warndim == true && exist('newuoas', 'file') == 2) % NEWUOAs is likely to outputperform NEWUOA when the problem is large enough.  
    warning('NEWUOA:Dimension', 'For problems with at least 30 variables, NEWUOAs is likely to\noutperform NEWUOA, especially if the problem is nonsmooth or noisy.\nSet options.subspace = true to use NEWUOAs.\nSet options.warndim = false to turn off this warning.');
end


[x, fx, exitflag, nf, fhist] = newuoa_mex(fun, x0, rhobeg, rhoend, maxfun, npt, ftarget);

if (debug == true)
    if (nf ~= size(fhist, 2) || (fx ~= min([fhist,fx]) && (fx == fx || min([fhist,fx]) == min([fhist,fx]))))
        error('NEWUOA:InvalidFhist', 'NEWUOA returns an fhist that does not match nf or fx.');
    end
    if (chkfunval == true)
        funx = feval(fun, x);
        if (funx ~= fx && (fx == fx || funx == funx))
            error('NEWUOA:InvalidFx', 'NEWUOA returns x and fx that do not not match.');
        end
    end
end

output.algorithm = 'NEWUOA';
switch exitflag
    case 0
        output.message = 'Return from NEWUOA because the lower bound for the trust region redius is reached.';
    case 1
        output.message = 'Return from NEWUOA because the target function value is achieved.';
    case 2
        output.message = 'Return from NEWUOA because a trust region step has failed to reduce the quadratic model.';
    case 3
        output.message = 'Return from NEWUOA because the objective function has been evaluated MAXFUN times.';
    case -1
        output.message = 'Return from NEWUOA because NaN occurs in x.';
    case -2
        output.message = 'Return from NEWUOA because the objective function returns an NaN or nearly infinite value.';
    otherwise 
        error('NEWUOA:InvalidExitflag', 'NEWUOA returns a wrong exitflag: %d.', exitflag);
end
output.funcCount = nf;
output.fhist = fhist;

return;
