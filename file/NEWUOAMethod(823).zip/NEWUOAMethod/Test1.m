clear all
warning off 
%%
%��ʼ������
n=3;
m=2*n+1;
rho_beg=1;
rho_end=10^(-6);
Max=20000;
xb=10*ones(n,1);
% xb=[-150;470;-150];
problem=[11 17 42 43 45 55 66 70 71 75 76];
%%
%���Ժ���
load('titles.mat')
F_test=@(x)(TestProblemF(x,n,titles(10)));
global Xn Fn n m F_times rho_beg rho_end x0 opt xb c g Gamma gamma H F rho delta Krho D3 QF3 CRVMIN d NORMD Qnew 
global RATIO MOVE w Hw beta Fnew DIST XXopt NXX 
global Test DandR Steps
Test=[];
DandR =[];
Steps=[];
[Fopt1,Xopt1,NF1] = NEWUOAMethodV1(F_test,m,n,xb,rho_beg,rho_end,Max);
 Test=[];
 DandR =[];
 Steps=[];
[Fopt2,Xopt2,NF2] = NEWUOAMethodV2(F_test,m,n,xb,rho_beg,rho_end,Max);
[Xopt3,Fopt3] = fminsearch(F_test,xb);
    
