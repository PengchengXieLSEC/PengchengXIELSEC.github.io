function [] = NEWUOAStep14()
%NEWUOAStep14 ��ӦNEWUOA�㷨�ĵ�ʮ�Ĳ�

global CRVMIN D3 QF3 rho Krho
global Steps %������
Steps=[Steps;14];
if Krho>=3

TEMP=0.125*CRVMIN*rho*rho;
if max(QF3)<=TEMP&&max(D3)<=rho
    NEWUOAStep11();%To Setp11
else
    NEWUOAStep15();%To Setp15
end
else
    NEWUOAStep15();%To Setp15
end

end