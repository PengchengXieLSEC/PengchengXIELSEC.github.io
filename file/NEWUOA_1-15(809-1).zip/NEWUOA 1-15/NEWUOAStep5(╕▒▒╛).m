function [] = NEWUOAStep5()
%NEWUOAStep5 ��ӦNEWUOA�㷨�ĵ��岽
% ����ǰ��ļ�����²�ֵ�ڵ�
global m n d MOVE Krho D3 QF3 NORMD Xn Fn opt x0 Qnew Fnew c g Gamma gamma H w Hw beta
global Test F_times
%%
%���㲽��14�Ĳα���
K=mod(Krho,3)+1;
D3(K)=NORMD;
QF3(K)=abs(Qnew-Fnew);
%%
t=MOVE;
if t>0
%%
%�ж��Ƿ�øı�x0
XX=Xn-x0;
% s=Xn(:,opt)-x0;
s=XX(:,opt);
NS2=s'*s; 
xnew=Xn(:,opt)+d;
%%
Qn=zeros(m,1);
QQ=Q(xnew);
x1=xnew;
for i=1:m
    Qn(i)=Q(Xn(:,i));
end
%%
if (NORMD*NORMD<=(0.001*NS2 ))
    x0=Xn(:,opt);
    %%
    X=zeros(n+1,m);
    XX=Xn-x0;
    X(1,:)=ones(1,m);
    X(2:n+1,:)=XX;
    A=zeros(m,m);
for i=1:m
    for j=1:m
        A(i,j)=0.5*(XX(:,i)'*XX(:,j))^2;
    end
end
W=zeros(m+n+1,m+n+1);
W(1:m,1:m)=A;
W(1:m,m+1:m+n+1)=X';
W(m+1:m+n+1,1:m)=X;
H=inv(W);
    %%
    %�¼���w,Hw�Լ�beta
    w=zeros(m+n+1,1);
    dxx0=xnew-x0;
    for i=1:m
    w(i)=0.5*(((Xn(:,i)-x0)'*(dxx0))^2);
    end
    w(m+1)=1;
    w(m+2:m+n+1)=dxx0;
    Hw=H*w;
    beta=0.5*((dxx0'*dxx0)^2)-w'*Hw;
    r=zeros(m+n+1,1);
    for i=1:m
        r(i)=Fn(i);
    end
%     Lcg=H*r;
%   Lcg=W\r;
%   [L,U] = lu(W);
%    [U,S,V] = svd(W);
%     Lcg = linsolve(W,r);
%    Lcg=V*inv(S)*U'*r;
    %y=L\r;
    %Lcg1=U\y;
    Lcg=H*r;
    gamma=Lcg(1:m);
    c=Lcg(m+1);
    g=Lcg(m+2:m+n+1);
    Gamma=zeros(n,n);
else
    %%
    %���޸�x0������ֱ�ӵ���H,w,Hw,beta,
end
%%
Qnewn=zeros(m,1);
QQnewn=Q(xnew);
x2=xnew;
for i=1:m
    Qnewn(i)=Q(Xn(:,i));
end
%%
%%
%��ʼ����ģ��
alpha=H(t,t);
tau=Hw(t);
% sigma=max([0,alpha])*max([0,beta])+tau^2;
sigma=alpha*beta+tau^2;
et=zeros(n+m+1,1);
et(t)=1;
eHw=et-Hw;
H=H+(    alpha*(eHw*eHw')-beta*H(:,t)*H(t,:) +tau*(H(:,t)*eHw'+eHw*H(t,:) ) )/sigma;
C=Fnew-Qnew;
Lcg=C*H(:,t);
lambda=Lcg(1:m);
dc=Lcg(m+1);
dg=Lcg(m+2:m+n+1);
%%
c=c+dc;
g=g+dg;
Gamma=Gamma+gamma(t)*XX(:,t)*XX(:,t)';
for i=1:m
    if i~=t
        gamma(i)=gamma(i)+lambda(i);
    else
        gamma(i)=lambda(i);
    end
end

if Fnew<Fn(opt)
    opt=t;%�������ŵ�λ�ã������²�ֵ��
    Fn(t)=Fnew;
    Xn(:,t)=xnew;
else
    %ֻ���µ�
    Fn(t)=Fnew;
    Xn(:,t)=xnew;
end











else
    %ģ�Ͳ���
end

%% ���ڲ���
% [HE] = HError()
Test(F_times-m+1,:)=[Xn(:,opt)',Fn(opt)];
% [E,en] = InterpolationError();
%  E
% [HE,W,Hreal] = HError();
% HE
%%
% global RATIO delta rho F_times
% F_times
% RATIO
% delta
% rho
% x0
% xopt=Xn(:,opt)
% Fopt=Fn(opt)
[E,en] = InterpolationError();
E
NEWUOAStep6();%To Setp6




end