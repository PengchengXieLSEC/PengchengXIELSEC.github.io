function F=SPHERECON(x)
global x0
F=norm(x-x0)-16;
end
