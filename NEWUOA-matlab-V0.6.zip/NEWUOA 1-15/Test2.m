clear all
%%
%���Ժ���
% F_test=@(x)(   x'*x +100*((x'*x-1))^2 );
% F_test=@(x)(   (x'*x)^2  );
% F_test=@(x)(   (x'*x)  );
%%
%��ʼ������
n=2;
m=2*n+1;
rho_beg=1;
rho_end=10^(-6);
Max=100;
xb=[100;100];
% xb=[100];
%%
global Xn Fn n m F_times rho_beg rho_end x0 opt xb c g Gamma gamma H F rho delta Krho D3 QF3 CRVMIN d NORMD Qnew 
global RATIO MOVE w Hw beta Fnew DIST XXopt NXX 
global Test DandR
[Fopt,xopt] = NEWUOAMethod(F_test,m,n,xb,rho_beg,rho_end,Max);